
import java.util.Scanner;

public class Principal {

    public static void main(String args[]) {
        Scanner ler = new Scanner(System.in);

        Conta c1 = new Conta();

        System.out.println("Informe o número da conta:");
        int nuConta = ler.nextInt();

        c1.colocarNumConta(nuConta);

        c1.depositar(0);

        c1.imprimirSaldo();

        System.out.println("Escolha a opção desejada:");
        System.out.println("1 - Depósito.");
        System.out.println("2 - Saque.");
        System.out.println("3 - Saldo na tela.");

        int opca = ler.nextInt();

        if (opca == 1) {

            System.out.println("Digite o valor do depósito: ");
            float dep = ler.nextFloat();
            if (dep <= 0) {
                System.out.println("O valor de depósito deve ser superior a 1.");
            } else {

                c1.depositar(dep);

                c1.imprimirSaldo();
            }
        }
        if (opca == 2) {

            System.out.println("Digite o valor do saque: ");
            float saq = ler.nextFloat();

            c1.sacar(saq);

            c1.imprimirSaldo();
        }
        if (opca == 3) {

            c1.imprimirSaldo();
        }
    }

}
