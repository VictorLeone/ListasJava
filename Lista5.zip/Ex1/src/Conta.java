public class Conta {
    private int opNum;
    private int numConta;
    private int agencia;
    private int tipo;
    private float saldo;
    
    public void depositar(float valorDeposito){
        saldo = saldo+valorDeposito; 
    }
    
    public void sacar (float valorSaque){
        saldo = saldo-valorSaque;
    }
    
    public void imprimirSaldo(){
        System.out.println("O saldo da conta "+printConta()+ " é: "+saldo);
    }
    
    public void colocarNumConta(int num){
        numConta = num;
    }
    
    public int printConta(){
    return numConta; 
    }
    }

