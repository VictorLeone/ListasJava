import java.util.Scanner;

public class RetanguloTeste {
    public static void main(String[] args) {
      
    Scanner retSc = new Scanner(System.in); 
    
    Retangulo r1 = new Retangulo();
    
    System.out.println("Informe a altura do retângulo:");
    r1.setX(retSc.nextInt());
    
    System.out.println("Informe a largura do retângulo:");
    r1.setY(retSc.nextInt());
    
    r1.setArea(0);
    
    System.out.println("A área do retângulo é: "+r1.area);
}
}
