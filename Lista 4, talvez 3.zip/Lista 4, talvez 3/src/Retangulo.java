
public class Retangulo {

    public int x;
    public int y;
    public int area;

    Retangulo() {
    }

    public int getX(int x) {
        return this.x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY(int y) {
        return this.y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getArea(int area) {
        return this.area;
    }

    public void setArea(int area) {
        this.area = x * y;
    }

    public Retangulo(int x, int y, int area) {

    }
}
