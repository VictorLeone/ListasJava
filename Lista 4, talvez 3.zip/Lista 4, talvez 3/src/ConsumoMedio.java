
public class ConsumoMedio {

    public int km1;
    public int km2;
    public int km3;
    public int cb1;
    public int cb2;
    public int cb3;
    public float con1;
    public float con2;
    public float con3;
    public float cont;

    public ConsumoMedio(int km1, int km2, int km3, int cb1, int cb2, int cb3, float con1, float con2, float con3) {
    }

    public ConsumoMedio(float cont) {
    }

    ConsumoMedio() {
    }

    public int getKm1(int km1) {
        return this.km1;
    }

    public void setKm1(int km1) {
        this.km1 = km1;
    }

    public int getKm2(int km2) {
        return this.km2;
    }

    public void setKm2(int km2) {
        this.km2 = km2;
    }

    public int getKm3(int km3) {
        return this.km3;
    }

    public void setKm3(int km3) {
        this.km3 = km3;
    }

    public int getCb1(int cb1) {
        return this.cb1;
    }

    public void setCb1(int cb1) {
        this.cb1 = cb1;
    }

    public int getCb2(int cb2) {
        return this.cb2;
    }

    public void setCb2(int cb2) {
        this.cb2 = cb2;
    }

    public int getCb3(int cb3) {
        return this.cb3;
    }

    public void setCb3(int cb3) {
        this.cb3 = cb3;
    }

    public float getCon1(float con1) {
        return this.con1;
    }

    public void setCon1(float con1) {
        this.con1 = km1 / cb1;
    }

    public float getCon2(float con2) {
        return this.con2;
    }

    public void setCon2(float con2) {
        this.con2 = km2 / cb2;
    }

    public float getCon3(float con3) {
        return this.con3;
    }

    public void setCon3(float con3) {
        this.con3 = km3 / cb3;
    }

    public float getCont(float cont) {
        return this.cont;
    }

    public void setCont(float cont) {
        this.cont = (con1 + con2 + con3) / 3;
    }

}
