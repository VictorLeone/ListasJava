import java.util.Scanner;

public class BuscaMaiorMenorTeste {
  public static void main(String[] args) {
      
    Scanner rd1 = new Scanner(System.in); 
    
    BuscaMenorMaior b1 = new BuscaMenorMaior();
    
    System.out.println("Informe cinco números em sequência:");
    
    b1.setN1(rd1.nextInt());
    b1.setMaior(b1.n1);
    b1.setMenor(b1.n1);
    
    b1.setN2(rd1.nextInt());
    if (b1.n2 >= b1.maior){
            b1.setMaior(b1.n2);
    }else{
        b1.setMenor(b1.n2);
    }
    
        b1.setN3(rd1.nextInt());
    if (b1.n3 >= b1.maior){
            b1.setMaior(b1.n3);
    }else{
        b1.setMenor(b1.n3);
    }
    
        b1.setN4(rd1.nextInt());
    if (b1.n4 >= b1.maior){
            b1.setMaior(b1.n4);
    }else{
        b1.setMenor(b1.n4);
    }
    
        b1.setN5(rd1.nextInt());
    if (b1.n5 >= b1.maior){
            b1.setMaior(b1.n5);
    }else{
        b1.setMenor(b1.n5);
    }
    
        System.out.println("O maior número da sequência é: "+b1.maior);
        System.out.println("O menor número da sequência é: "+b1.menor);
    
}
}
