
import java.util.Scanner;

public class ConsumoMedioTeste {

    public static void main(String[] args) {

        Scanner combSc = new Scanner(System.in);

        ConsumoMedio c1 = new ConsumoMedio();

        System.out.println("Informe as distâncias percorridas e as quantidades de combustível gasto:");

        System.out.print("Distância 1: ");
        c1.setKm1(combSc.nextInt());

        System.out.print("Quantidade de combustível gasto: ");
        c1.setCb1(combSc.nextInt());

        System.out.print("Distância 2: ");
        c1.setKm2(combSc.nextInt());

        System.out.print("Quantidade de combustível gasto: ");
        c1.setCb2(combSc.nextInt());

        System.out.print("Distância 3: ");
        c1.setKm3(combSc.nextInt());

        System.out.print("Quantidade de combustível gasto: ");
        c1.setCb3(combSc.nextInt());

        c1.setCon1(0);
        c1.setCon2(0);
        c1.setCon3(0);
        c1.setCont(0);
        
        System.out.println("Consumo do ciclo 1: " +c1.con1+" km/l.");
        System.out.println("Consumo do ciclo 2: " +c1.con2+" km/l.");
        System.out.println("Consumo do ciclo 3: " +c1.con3+" km/l.");
        System.out.println("Consumo total dos ciclos: " +c1.cont+" km/l.");
    }
}
