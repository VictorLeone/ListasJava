
public class BuscaMenorMaior {

    public int n1;
    public int n2;
    public int n3;
    public int n4;
    public int n5;
    public int maior;
    public int menor;

    BuscaMenorMaior() {
      
    }

    public int getN1(int n1) {
        return this.n1;
    }

    public void setN1(int n1) {
        this.n1 = n1;
    }

    public int getN2(int n2) {
        return this.n2;
    }

    public void setN2(int n2) {
        this.n2 = n2;
    }

    public int getN3(int n3) {
        return this.n3;
    }

    public void setN3(int n3) {
        this.n3 = n3;
    }

    public int getN4(int n4) {
        return this.n4;
    }

    public void setN4(int n4) {
        this.n4 = n4;
    }

    public int getN5(int n5) {
        return this.n5;
    }

    public void setN5(int n5) {
        this.n5 = n5;
    }

    public int getMaior(int maior) {
        return this.maior;
    }

    public void setMaior(int maior) {
        this.maior = maior;
    }

    public int getMenor(int menor) {
        return this.menor;
    }

    public void setMenor(int menor) {
        this.menor = menor;
    }

    public BuscaMenorMaior(int n1, int n2, int n3, int n4, int n5, int maior, int menor) {
    }
}
