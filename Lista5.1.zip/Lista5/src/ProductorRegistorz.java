

public class ProductorRegistorz {
    public static void main(String[] args){
        
        Pedido p1 = new Pedido();
        p1.setCodPedido(1142456);
        p1.setNomeCliente("Crezilda");
        p1.setDescPedido("Aulas de Java na Udemy.");
        p1.print();
        
        p1.setCodPedido(1142456);
        p1.setNomeCliente("Aldo");
        p1.setDescPedido("Aulas de Java na UNIEURO.");
        p1.print();
    }
}
