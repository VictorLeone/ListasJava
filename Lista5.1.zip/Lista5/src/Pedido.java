
public class Pedido {

    int codPedido;
    String nomeCliente;
    String descPedido;

    public int getCodPedido(int x){
        return this.codPedido;
    }
    public String getNomeCliente (String nc){
        return this.nomeCliente;
    }
    public String getDescPedido (String dp){
        return this.descPedido;
    }
    public void setCodPedido(int x){
        this.codPedido = x;
    }
    public void setNomeCliente(String nc){
            this.nomeCliente = nc;
    }
    public void setDescPedido(String dp){
        this.descPedido = dp;
    }
   public void print(){
       System.out.println("Informações do pedido #"+this.codPedido+":");
       System.out.println("Cliente: "+this.nomeCliente);
       System.out.println("Descrição: "+this.descPedido);
   }
}